package com.example.chartroom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChartroomApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChartroomApplication.class, args);
    }

}
